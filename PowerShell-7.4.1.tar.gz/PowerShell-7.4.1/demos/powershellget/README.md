## PowerShellGet demo

PowerShellGet is a PowerShell module with the commands for discovering, installing, updating and publishing the PowerShell artifacts like Modules, DSC Resources, Role Capabilities and Scripts.

This demo shows discovering, installing, updating, uninstalling the PowerShell scripts from an online repository.
